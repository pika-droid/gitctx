# Chapter III: System Design and Methodology

This chapter details the architectural design and implementation of the **gitctx** engine. To transform raw version control logs into a high-precision, semantic retrieval index, the system couples deterministic static analysis with hybrid information retrieval, resilient function lineage tracking, and statistical co-change modeling. The entire architecture is implemented in idiomatic Rust and structured into modular crates designed to operate strictly offline without external cloud dependencies.

---

## 3.1 Architectural Overview and System Invariants

The `gitctx` engine is structured as a Cargo workspace comprising six specialized crates that decouple concerns across the data pipeline:

* **`gitctx-core`:** Core domain models, native Git repository traversal, Tree-sitter abstract syntax tree (AST) extraction, secret sanitization, and the multi-tier function lineage resolver.
* **`gitctx-index`:** High-throughput storage orchestration, managing Tantivy-based BM25 inverted indexes, dense float vector binary storage (`vectors.bin`), and SQLite relational persistence.
* **`gitctx-query`:** Hybrid retrieval engine executing Reciprocal Rank Fusion, exact-match fast paths, and statistical co-change impact analysis.
* **`gitctx-cli`:** Native command-line interface providing interactive query capabilities, lineage inspection, and impact reporting for developers.
* **`gitctx-mcp`:** Model Context Protocol (MCP) server exposing history retrieval tools to autonomous coding agents via standard input/output (`stdio`) JSON-RPC.
* **`gitctx-eval`:** Experimental evaluation harness, benchmarking automation, and statistical report generator enforcing pre-registered decision gates.

```
+--------------------------------------------------------------------------------------------------+
|                                    gitctx System Architecture                                    |
+--------------------------------------------------------------------------------------------------+
|                                                                                                  |
|  [ Git Repository ]                                                                              |
|          |                                                                                       |
|          v                                                                                       |
|  +--------------------+                                                                          |
|  | First-Parent Walker| (Invariant I8: libgit2 first-parent commit stream)                        |
|  +--------------------+                                                                          |
|          |                                                                                       |
|          v                                                                                       |
|  +--------------------+       Diff-Hunk Range Check                                              |
|  | Tree-sitter Parser | ---------------------------------+                                       |
|  +--------------------+                                  |                                       |
|          | (Active AST Function Touches)                 v (Suppresses 63.1% ghost touches)      |
|          +-----------------------+-----------------------+                                       |
|                                  |                                                               |
|        +-------------------------+-------------------------+                                     |
|        |                                                   |                                     |
|        v                                                   v                                     |
|  +---------------------------+               +---------------------------+                       |
|  | 4-Tier Lineage Engine     |               | D4 Template Renderer      |                       |
|  |  Tier 1: Exact Key        |               |  - Qualified Name & File  |                       |
|  |  Tier 2: Same-File MinHash|               |  - Sanitized Commit Log   |                       |
|  |  Tier 3: Rename Map Cross |               |  - Diff Identifiers (+/-) |                       |
|  |  Tier 4: Cross-File LSH   |               |  - AST Post-Change Sig    |                       |
|  +---------------------------+               |  - Contextual Docstring   |                       |
|        |                                     +---------------------------+                       |
|        |                                                   |                                     |
|        v                                                   v                                     |
|  +--------------------+                       +---------------------------+                      |
|  | SQLite Storage     |                       | Dual-Index Storage Tier   |                      |
|  |  - Commits & Touches                       |  - Tantivy BM25 (Lexical) |                      |
|  |  - Lineage DAGs    |                       |  - ONNX BGE-Small (Dense) |                      |
|  |  - Co-Change Graph |                       +---------------------------+                      |
|  +--------------------+                                    |                                     |
|        |                                                   |                                     |
|        +-------------------------+-------------------------+                                     |
|                                  |                                                               |
|                                  v                                                               |
|  +-------------------------------------------------------+                                       |
|  | Hybrid Query Engine & Reciprocal Rank Fusion (k = 60) |                                       |
|  |  - Rank-0 Exact Match Fast Path                       |                                       |
|  |  - Half-Life Exponential Co-Change Decay Scorer       |                                       |
|  +-------------------------------------------------------+                                       |
|                                  |                                                               |
|                 +----------------+----------------+                                              |
|                 v                                 v                                              |
|         [ gitctx-cli ]                     [ gitctx-mcp ]                                        |
|      (Human Terminal UI)             (Local stdio JSON-RPC for LLMs)                             |
|                                                                                                  |
+--------------------------------------------------------------------------------------------------+
```

To eliminate nondeterministic behavior and guarantee research-grade reproducibility, the system enforces eight mechanically audited design invariants:

1. **Invariant I1 (Zero Network Activity):** All indexing, parsing, vector embedding, and query retrieval operations execute strictly offline. Embedding model weights are packaged locally, and CI pipelines verify this isolation in an un-routed network namespace.
2. **Invariant I2 (Deterministic Output):** Ingesting the same repository commit sequence yields identical database states and checksums, enforced by deterministic tie-breaking across all ranking and lineage-matching algorithms.
3. **Invariant I3 (Incremental Equivalence):** Progressively indexing commits one by one produces an identical persistent state to a cold full-index run evaluated over the same terminal commit.
4. **Invariant I4 (Non-Null Citations):** Every record returned by the retrieval engine includes complete, validated provenance—specifically the commit SHA, author identity, timestamp, and target file path.
5. **Invariant I5 (Isolated Explain Cache):** Optional natural-language summarization or LLM annotation layers reside in an isolated SQLite table disabled by default, preventing stochastic outputs from altering core retrieval data.
6. **Invariant I6 (Pinned Evaluation Corpus):** Benchmark repositories are pinned at immutable commit hashes in `eval/corpus.lock.toml` and verified using BLAKE3 and SHA-256 digests before evaluation execution.
7. **Invariant I7 (Stated Baselines and Statistical Uncertainty):** Any empirical metric reported by the evaluation harness must include an explicit baseline delta and a 95% bootstrap confidence interval.
8. **Invariant I8 (First-Parent Traversal Enforcement):** The Git extraction engine strictly follows first-parent commit edges, preventing double-counting of squash-merged and feature-branch diffs.

These invariants are validated automatically via `cargo xtask test-invariants`, which executes continuous integration checks against synthetic and real repository fixtures.

---

## 3.2 Git Extraction and Structural Differencing

The extraction subsystem ingests commit graphs via `libgit2` bindings provided by the `git2` crate. Crucially, the underlying C library is statically bundled and compiled during the build process, preventing runtime discrepancies across different host operating systems.

### 3.2.1 First-Parent Traversal Strategy
In modern team workflows, feature branches are frequently merged into primary branches (`main` or `master`) through merge commits. Traversing all topological paths in a branched commit graph leads to severe data contamination: modifications made inside a branch would be ingested once during the branch commits and a second time when analyzing the composite merge commit. This duplicate indexing artificially inflates function modification counts and introduces false co-change coupling. Under Invariant I8, `gitctx` enforces a strict first-parent walk, treating merge commits as single integration snapshots reflecting what actually landed on the release branch.

### 3.2.2 AST Differencing and Diff-Hunk Filtering
For each commit node, the system computes a structural tree diff against its first parent. Using Git's similarity metrics, file transitions are categorized as additions, modifications, deletions, or renames. While conventional tools stop at file-level diffs, `gitctx` feeds modified file buffers directly into Tree-sitter parsers supporting Go, Rust, and Python.

To eliminate *ghost touches*—instances where a file is modified but specific functions within that file remain untouched—the extractor calculates the exact line ranges of all diff hunks. Only AST function boundaries that directly intersect modified lines are recorded as genuine function touches. On large codebases, this hunk-filtering mechanism prunes over $63\%$ of redundant AST operations.

### 3.2.3 Fault-Tolerant Parsing
Historical repositories inevitably contain legacy syntax, incomplete transitions, or malformed source blobs. To ensure that parsing anomalies do not abort the pipeline, each extracted record contains a `parse_status` flag (`ok`, `degraded`, or `failed`). When Tree-sitter encounters unparseable syntax, the engine logs a degraded status and emits a coarse file-level chunk, maintaining indexing continuity without crashing.

---

## 3.3 Pseudo-Document Template Rendering (D4)

A central insight of this work is that raw unified diffs are structurally ill-suited for natural language retrieval. Diff syntax (`@@ -12,7 +12,9 @@`, `+`, `-`) introduces substantial syntactic noise that misleads tokenizers and distorts semantic dense embeddings.

To resolve this vocabulary gap, `gitctx` implements the **D4 Template Renderer**, which synthesizes each function touch into a cohesive natural-language pseudo-document composed of six canonical sections:
1. **Header Metadata:** Normalizes the function's fully qualified identifier, file path, author name, and ISO timestamp.
2. **Sanitized Commit Message:** The original commit log message, cleaned of issue-tracker boilerplate and verified against regex credential patterns.
3. **Introduced Identifiers:** High-signal programming tokens added to the function body, extracted by splitting diff lines on camelCase and snake_case boundaries while discarding language-specific keywords.
4. **Deleted Identifiers:** Programming tokens removed from the function body, capturing deprecated logic or obsolete dependencies.
5. **Post-Change Signature:** The updated function prototype, parameter list, and return types derived directly from the post-commit AST.
6. **Contextual Docstring:** Inline comments or documentation blocks immediately preceding the function declaration.

Before serialization, a `SecretRedactor` module performs high-entropy scanning and regex pattern matching to scrub potential API keys, access tokens, and private secrets from the indexed document text.

---

## 3.4 Multi-Tier Function Lineage Engine

Tracking a function's evolutionary history requires maintaining continuity across refactoring operations. Standard version control tools track file paths rather than abstract code entities; once a function is renamed or extracted into a different file, its history is fragmented.

`gitctx` models function lineage through a persistent `LineageId`—a monotonically increasing unique identifier assigned to each logical function. Commits are processed chronologically, matching active symbols from commit $N-1$ against newly parsed symbols in commit $N$ using a four-tier resolution cascade:

* **Tier 1 (Exact Triplet Match):** Compares the triplet `(normalized_path, qualified_name, signature)`. If identical, the function represents an in-place modification and preserves its `LineageId`.
* **Tier 2 (Same-File MinHash):** When Tier 1 fails but the entity remains within the same file path, the engine tokenizes the function body into overlapping 3-shingles (trigrams) and computes a 128-permutation MinHash signature using Murmur3. If the estimated Jaccard similarity exceeds the calibrated threshold $\tau_{\text{same}} = 0.55$, continuity is established. Trivial boilerplate functions ($< 10$ tokens) are bypassed.
* **Tier 3 (Git Rename Cross-Referencing):** If Git's structural diff detects that a file was renamed and the function's qualified name is preserved, the engine maps the lineage across the file boundary.
* **Tier 4 (Cross-File MinHash with LSH Banding):** When a function is relocated across modules or extracted into a utility file, the engine searches all candidate active symbols. To avoid pairwise comparison overhead, candidate pairs are pre-filtered into hash buckets using Locality-Sensitive Hashing (LSH) banding before computing full MinHash similarity against $\tau_{\text{cross}} = 0.65$.

```
[ Commit N vs Commit N-1 Symbol Sets ]
                 |
                 v
       +--------------------+
       | Tier 1: Exact Key  | ----> [Match] ---> Preserve LineageId
       +--------------------+
                 | (Fail)
                 v
       +--------------------+
       | Tier 2: Same-File  | ----> [Match: Jaccard >= 0.55] ---> Preserve LineageId
       |  128-perm MinHash  |
       +--------------------+
                 | (Fail)
                 v
       +--------------------+
       | Tier 3: Rename Map | ----> [Match: File Renamed] ---> Preserve LineageId
       +--------------------+
                 | (Fail)
                 v
       +--------------------+
       | Tier 4: Cross-File | ----> [Match: Jaccard >= 0.65] ---> Preserve LineageId
       |  LSH Scoped Search |
       +--------------------+
                 | (Fail)
                 +------------------------> [No Match: Allocate New LineageId]
```

Candidate pairings are evaluated using greedy bipartite matching sorted by confidence score. Any candidate matching below the decoy rejection threshold ($\tau_{\text{decoy}} = 0.20$) is rejected, preventing accidental linkage of unrelated boilerplate functions.

---

## 3.5 Hybrid Retrieval and Storage Architecture

To achieve sub-300ms query latency while guaranteeing complete offline operation, `gitctx` partitions storage across three specialized data engines:

### 3.5.1 Storage Layer
* **SQLite (WAL Mode):** Stores tabular commit metadata, raw touch records, lineage ancestry graphs, and co-change statistics. Writes are serialized asynchronously via a dedicated worker thread over crossbeam channels to prevent disk contention during AST extraction.
* **Tantivy Inverted Index:** Maintains BM25 lexical postings for all D4 pseudo-documents, utilizing a custom tokenizer engineered for programming language identifiers.
* **Memory-Mapped Vector File (`vectors.bin`):** Stores 384-dimensional dense embeddings generated by the pre-packaged `BGE-Small-EN-v1.5` model. Running locally through ONNX Runtime, embeddings are persisted in a flat binary file that is memory-mapped at query time. This eliminates memory exhaustion and enables rapid exact nearest-neighbor cosine scanning.

### 3.5.2 Query Fusion and Exact-Match Fast Path
When a query arrives, the system executes lexical BM25 and dense semantic retrieval concurrently. The two ranked lists are combined using Reciprocal Rank Fusion (RRF):

$$RRF(d) = \sum_{r \in \mathcal{R}} \frac{1}{k + rank(r, d)}$$

where the constant $k = 60$ prevents top-ranked outliers from disproportionately dominating the fused results.

To ensure immediate resolution when developers search for known functions or specific commit hashes, the engine incorporates an exact-match fast path: if the query string exactly matches an indexed symbol or SHA prefix, the record is immediately retrieved from SQLite and assigned a priority bonus, ensuring it surfaces at rank zero. Ties are deterministically resolved by sorting on the internal touch primary key.

---

## 3.6 Co-Change Coupling and Temporal Decay

In addition to searching historical text, understanding architectural change risk requires analyzing historical co-change patterns. When two entities are repeatedly modified within the same commits, they exhibit *logical coupling* that may not be apparent from static code dependencies.

### 3.6.1 Filtering Bulk Commits
Large refactorings, automated dependency bumps, and mass-formatting passes modify dozens or hundreds of files simultaneously. Including these commits would generate thousands of spurious co-change edges. Therefore, the co-change engine discards any commit modifying more than $25$ files, focusing exclusively on targeted functional modifications.

### 3.6.2 Association Rules and Half-Life Decay
For every qualifying commit, the engine records co-occurrence across modified files and functions, computing Support, Confidence, and Lift:

$$\text{Lift}(A, B) = \frac{P(A \land B)}{P(A) \cdot P(B)}$$

To reflect software evolution realistically, recent modifications must carry greater diagnostic significance than historical changes. The engine applies an exponential half-life decay function:

$$w(t) = 2^{-\frac{t_{\text{ref}} - t}{h}}$$

where $t_{\text{ref}}$ is the current index timestamp, $t$ is the commit timestamp, and $h$ is the configurable half-life (set to $180\text{ days}$ by default). Under this model, co-change coupling from 180 days ago contributes half its original weight ($0.50$), while changes from two years ago decay to approximately $6.25\%$, preventing outdated architectural topologies from skewing current risk assessments.

---

## 3.7 Output Interfaces and Agent Integration

`gitctx` exposes its historical intelligence through two primary interfaces:
1. **Interactive CLI (`gitctx-cli`):** Provides command-line search, function lineage timelines, and change impact scores directly in the developer's terminal.
2. **Model Context Protocol Server (`gitctx-mcp`):** Bridges repository history directly into autonomous AI coding assistants (such as Claude Code, Cursor, or Gemini CLI) via standard input/output (`stdio`) JSON-RPC.

The MCP server exposes five purpose-built tools:
* `search_history`: Executes hybrid search over historical D4 pseudo-documents.
* `function_evolution`: Retrieves the unbroken chronological transformation history of a specific function across all refactorings.
* `change_impact`: Computes decay-weighted co-change risk and lists coupled files for a proposed modification.
* `who_knows_this`: Identifies domain experts by computing historical modification frequency and recency.
* `commit_detail`: Returns full contextual metadata and AST changes for a specific commit hash.

To prevent token window exhaustion in calling language models, each tool supports configurable verbosity modes (`compact`, `standard`, and `full`). Furthermore, the server maintains strict protocol isolation: all internal diagnostic logging is routed exclusively to `stderr`, guaranteeing that `stdout` contains pristine JSON-RPC messages. The server process maintains a warm in-memory ONNX session to avoid reload overhead while executing each query statelessly against the underlying local index.
