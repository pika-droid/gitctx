# Chapter V: Evaluation Methodology and Experimental Setup

This chapter establishes the empirical evaluation framework and benchmarking protocols designed to validate **gitctx**. We formulate multi-language repository gating criteria, non-circular ground-truth extraction pipelines, and statistical ablation suites to systematically assess retrieval efficacy, function lineage tracking fidelity, and mechanical invariant compliance.

---

## 5.1 Evaluation Framework and Scope

The `gitctx` evaluation framework evaluates four orthogonal dimensions of system correctness:
1. **Retrieval Efficacy:** Precision and ranking fidelity when retrieving historical design rationale in response to intent-oriented queries.
2. **Lineage Tracking Fidelity:** Continuous identity tracking across structural refactorings, file moves, and extractions.
3. **Cryptographic Integrity & Non-Circularity:** Verifiable dataset pinning, tamper-proof manifests, and automated prevention of ground-truth leakage into indexed text.
4. **Mechanical Verification:** Automated testing of core system invariants (I1–I8) and operational latency budgets.

All benchmark artifacts—including repository clone manifests, issue-closing pairs, curated why-queries, mutation fixtures, and calibrated thresholds—are deterministically pinned via `eval/corpus.lock.toml` (Invariant I6) and cryptographically sealed with BLAKE3 and SHA-256 digests in `eval/ground_truth/MANIFEST.toml`.

```
+--------------------------------------------------------------------------------------------------+
|                                  Evaluation Methodology Flow                                     |
+--------------------------------------------------------------------------------------------------+
|                                                                                                  |
|  [ 15 Candidate Open-Source Repositories ]                                                       |
|                     |                                                                            |
|                     v (Automated profiling via eval/profile.py)                                   |
|  +-------------------------------------------------------------+                                 |
|  | Multi-Language Gating Criteria                              |                                 |
|  |  - Traceable Issues >= 150                                  |                                 |
|  |  - Merge Fraction < 0.40                                    |                                 |
|  |  - Bot Ratio <= 0.25                                        |                                 |
|  |  - Non-Universal Squash < 0.90                              |                                 |
|  +-------------------------------------------------------------+                                 |
|                     |                                                                            |
|                     v                                                                            |
|  [ Locked Evaluation Triad: Go (gin), Rust (tokio), Python (requests) ]                         |
|                     |                                                                            |
|          +----------+----------+---------------------------------------+                         |
|          |                     |                                       |                         |
|          v                     v                                       v                         |
|  +---------------+   +-------------------+                   +-------------------+               |
|  | Ground Truth  |   | Ground Truth      |                   | Synthetic Lineage |               |
|  | Set A         |   | Set B             |                   | Mutation Oracle   |               |
|  | (260 Issues)  |   | (27 Why-Queries)  |                   | (M1 - M10 Suite)  |               |
|  +---------------+   +-------------------+                   +-------------------+               |
|          |                     |                                       |                         |
|          v                     v (6-Stage Sanitizer: sanitize.py)      v (Grid Sweep: 66 pts)    |
|  +---------------+   +-----------------------------------+   +-------------------+               |
|  | Issue-Trailer |   | 5 x 5 Retrieval Ablation Grid     |   | Calibrated        |               |
|  | Verification  |   | D1-D5 Reps x R1-R5 Retrievers     |   | Thresholds        |               |
|  | (Audit n=30)  |   | Recall@K, MRR, Bootstrap CI       |   | F1 = 1.000        |               |
|  +---------------+   +-----------------------------------+   +-------------------+               |
|                                        |                                                         |
|                                        v                                                         |
|                      +-----------------------------------+                                       |
|                      | Decision Gate: Margin >= 0.05     |                                       |
|                      | Invariant Suite: xtask test-inv   |                                       |
|                      +-----------------------------------+                                       |
|                                                                                                  |
+--------------------------------------------------------------------------------------------------+
```

---

## 5.2 Corpus Selection and Multi-Language Gating Criteria

To guarantee cross-language generalization across diverse repository topologies, an evaluation triad spanning Go, Rust, and Python was selected from fifteen candidate open-source repositories using an automated profiler (`eval/profile.py`). The profiler evaluated repositories against four pre-registered gating rules:

1. **Traceable Closed Issue Density ($N_{\text{traceable}} \ge 150$):** Ensures a sufficient volume of high-confidence issue-commit links to support ground-truth extraction.
2. **Merge Commit Fraction ($f_{\text{merge}} < 0.40$):** Excludes repositories with un-curated merge topologies that inject severe noise into co-change matrices.
3. **Bot Commit Fraction ($f_{\text{bot}} \le 0.25$):** Prunes automated dependency bumps (e.g., Dependabot) that distort code churn metrics.
4. **Non-Universal Squash Ratio ($f_{\text{squash}} < 0.90$):** Preserves rich multi-commit evolutionary histories necessary for evaluating function lineage tracking.

### Selected Evaluation Triad

| Size Tier | Repository | Language | Total Commits | First-Parent Commits | Traceable Issues | Merge % | Bot % | Selection Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Small** | `gin-gonic/gin` | Go | 2,023 | 1,314 | 1,159 | 10.7% | 6.2% | **Selected** |
| **Medium** | `tokio-rs/tokio` | Rust | 4,783 | 4,182 | 4,299 | 3.9% | 0.1% | **Selected** |
| **Large** | `psf/requests` | Python | 6,495 | 2,669 | 333 | 24.8% | 1.0% | **Selected** |

Pinned commit SHAs are locked in `eval/corpus.lock.toml` under Invariant I6. Hard gating disqualified candidates such as `tiangolo/fastapi` ($f_{\text{bot}} = 44.5\%$) and `trpc/trpc` ($f_{\text{bot}} = 30.5\%$) due to excessive automated bot churn, while `sharkdp/fd` narrowly missed the traceability threshold ($N_{\text{traceable}} = 148$). Although `expressjs/express` met the structural criteria ($f_{\text{merge}} = 7.8\%$), it was reserved to maintain a balanced Go, Rust, and Python evaluation triad.

---

## 5.3 Ground-Truth Construction and Leakage Sanitization

Valid information retrieval evaluation requires eliminating circular evaluation paths. If evaluation queries contain verbatim identifiers or commit summaries that appear directly in indexed document text, measured accuracy reflects simple string copying rather than semantic retrieval.

`gitctx` constructs and isolates three independent ground-truth datasets (`eval/ground_truth/MANIFEST.toml`):

### 1. Set A: Issue-Closing Pairs ($N = 260$)
Extracted by combining regular-expression parsing of Git commit trailers (`Fixes: #N`, `Resolves: #N`) with authoritative GitHub Issue Timeline API events. To ensure quality, links are capped at three commits per issue, and bot commits are excluded. A manual audit of $n = 30$ randomly sampled pairs confirmed $100\%$ precision ($p = 1.000$, $95\%\text{ Wilson score CI: } [0.887, 1.000]$), validating the automated harvester against our $p \ge 0.85$ quality target.

### 2. Set B: Intent-Oriented Why-Queries ($N = 27$)
A complementary benchmark of 27 manually authored natural-language questions (9 per triad repository) designed to evaluate historical rationale recovery across four distinct categories:
* **Architectural Decisions:** High-level design choices and structural reorganizations.
* **Bug Root Causes:** Non-obvious defect resolutions and regression fixes.
* **API Evolution:** Breaking interface changes and deprecation motivations.
* **Performance Motivations:** Algorithmic optimizations and concurrency improvements.

### 3. Revert Pairs ($N = 42$)
Mined commit-revert pairs capturing self-contained code rollbacks, used to benchmark rollback analysis.

### Multi-Stage Leakage Sanitization
To prevent evaluation leakage, all commit text passes through a six-stage sanitizer (`eval/sanitize.py`):
1. **Issue Reference Stripping:** Eliminates `#123`, `GH-123`, and issue URL references.
2. **Pull Request URLs:** Prunes GitHub/GitLab pull request links.
3. **Commit Trailer Stripping:** Scrubs `Signed-off-by:`, `Co-authored-by:`, and action trailers.
4. **Squash Suffix Removal:** Removes automated GitHub squash commit suffixes (e.g., `(#456)`).
5. **Merge Boilerplate Filtering:** Strips standard `Merge pull request #... from ...` lines.
6. **Zero Gold-Rationale Assertion:** Automated tests (`test_zero_gold_rationale_leakage`) verify that no indexed pseudo-document contains textual substrings matching the benchmark rationale answers.

---

## 5.4 5 x 5 Retrieval Ablation Protocol

The central retrieval hypothesis states that structured pseudo-documents ($D_4$) outperform raw diffs and un-curated commit logs when searching version control history. To test this hypothesis, a full $5 \times 5$ ablation grid was designed, evaluating 25 distinct configurations across five document representations and five retrieval mechanisms:

### Document Representations ($D_1$–$D_5$)
* **$D_1$ (Commit Message Only):** Traditional commit log baseline without code diff context.
* **$D_2$ (Raw Diff Only):** Unstructured unified diff patch without commit log message.
* **$D_3$ (Message + Raw Diff):** Standard developer baseline combining commit log and raw patch text.
* **$D_4$ (Structured Pseudo-Document):** Canonical six-section D4 template combining metadata, sanitized message, identifier deltas, AST signatures, and surrounding docstrings.
* **$D_5$ (Ablated Template Without Message):** Structured D4 template with the commit message stripped, isolating the retrieval power of AST structural signals.

### Retrieval Strategies ($R_1$–$R_5$)
* **$R_1$ (Keyword Matching Baseline):** Exact substring matching simulating traditional `git log -S` code exploration.
* **$R_2$ (Code-Aware BM25):** Probabilistic BM25 ranking via `rank_bm25` with code-specific tokenization (snake_case and camelCase sub-token splitting).
* **$R_3$ (Standard Dense Embedding):** Sentence-transformer dense vector search using `all-MiniLM-L6-v2` with cosine similarity ranking.
* **$R_4$ (Code-Aware Dense Embedding):** Dense semantic representation using `microsoft/unixcoder-base` fine-tuned on programming languages.
* **$R_5$ (Hybrid Reciprocal Rank Fusion):** Reciprocal Rank Fusion ($k = 60$) combining code-aware BM25 ($R_2$) with dense retrieval ($R_3$), augmented with exact-match fast-path routing on structured representations ($D_4, D_5$).

### Metrics and Gating Criterion
Retrieval performance is evaluated using Recall@$K$ ($K \in \{5, 10, 20\}$) and Mean Reciprocal Rank (MRR):

$$\text{MRR} = \frac{1}{|Q|} \sum_{i=1}^{|Q|} \frac{1}{\text{rank}_i}$$

The pre-registered Phase 03 decision gate requires:

$$\Delta\text{Recall@10} = \text{Recall@10}(D_4 + R_5) - \text{Recall@10}(D_3 + R_1) \ge 0.05$$

accompanied by a 95% paired bootstrap confidence interval computed over 1,000 resamples using SplitMix64 (seed 42).

---

## 5.5 Function Lineage Mutation Oracle and Hunk Filtering

Because standard Git tools lack ground-truth benchmarks for cross-file function tracking, the lineage engine is evaluated using a synthetic mutation generator (`cargo xtask eval bench-lineage`).

### 5.5.1 Mutation Taxonomy ($M_1$–$M_{10}$)
The mutation generator constructs synthetic Git histories covering ten formal refactoring transformations:
* **$M_1$–$M_3$ (Renames and Moves):** In-place function rename ($M_1$), cross-file move ($M_2$), simultaneous move and rename ($M_3$).
* **$M_4$–$M_6$ (Signatures and Bodies):** Parameter type additions ($M_4$), docstring/formatting edits ($M_5$), local variable renaming ($M_6$).
* **$M_7$–$M_{10}$ (Structural Modifications):** Function extraction ($M_7$), adversarial delete-and-add decoy ($M_8$), directory reorganization ($M_9$), and multi-step chained refactoring at depth $D = 5$ ($M_{10}$).

### 5.5.2 Threshold Calibration
Lineage matching thresholds were calibrated using a 66-point grid sweep (`eval/lineage_thresholds.json`):
* $\tau_{\text{same}} = 0.55$: Same-file MinHash similarity (Tier 2).
* $\tau_{\text{cross}} = 0.65$: Scoped cross-file MinHash similarity (Tier 4).
* $\tau_{\text{decoy}} = 0.20$: Decoy rejection threshold penalizing false positives.

### 5.5.3 Diff-Hunk Overlap Filtering
To evaluate production efficiency, the system measures ghost-touch elimination by comparing full-file AST parsing against diff-hunk filtered parsing on 100 consecutive commits of `BurntSushi/ripgrep`.

---

## 5.6 Mechanical Invariants and Operational Budgets

Every CI build executes `cargo xtask test-invariants`, verifying eight mechanical system constraints:

| Invariant | Property Verified | Verification Method |
| :--- | :--- | :--- |
| **I1** | Zero Network Activity | Linux network namespace unshare (`xtask test-offline`) |
| **I2** | Deterministic Output | Bitwise SQLite database checksum match on repeated indexing |
| **I3** | Incremental Equivalence | State parity between incremental injection and full re-index |
| **I4** | Non-Null Citations | Schema assertion rejecting null SHA, author, or timestamps |
| **I5** | Isolated Explain Cache | Dedicated SQLite table isolation for non-deterministic LLM data |
| **I6** | Pinned Corpus SHA Lock | Cryptographic checksum match against `corpus.lock.toml` |
| **I7** | Stated Baselines & Uncertainty | Report generator fails if baseline delta or bootstrap CI is absent |
| **I8** | First-Parent Traversal | Assertion confirming zero second-parent commits in indexed graph |

Operational performance is evaluated against pre-defined engineering targets:
* Cold indexing throughput: $< 10\text{ minutes per 10,000 commits}$.
* Incremental commit latency: $< 2\text{ seconds per commit}$.
* Search query latency (P95): $< 300\text{ ms}$.
* MCP tool dispatch latency (P95): $< 500\text{ ms}$.
* Disk footprint: $< 100\text{ MB per 10,000 commits}$.

---

## 5.7 Pre-Registered Retrieval Failure Taxonomy

All retrieval misses (where a ground-truth commit is not surfaced within the top 10) are formally categorized into a ten-class failure taxonomy:

| Category | Diagnostic Root Cause |
| :--- | :--- |
| **AST Parse Degraded** | Tree-sitter syntax failure on historical blob; fallback to file-level chunk. |
| **Cross-File Rename Miss** | Relocated function where edits dropped MinHash similarity below $\tau_{\text{cross}}$. |
| **Directory Move Miss** | Function relocated outside the active LSH candidate search scope. |
| **Leakage Residual** | Issue IDs or trailers survived sanitization into indexed chunk text. |
| **Tokenization Boundary** | Identifier casing produced token splits hindering exact symbol matching. |
| **Sparse History Gap** | Commit modified $< 2$ functions, yielding insufficient ranking signals. |
| **Decoy False Positive** | Delete-and-add pair incorrectly accepted despite the decoy threshold. |
| **Dense Misalignment** | High vector similarity with an unrelated function due to vocabulary overlap. |
| **Vocabulary Gap** | Natural-language query used terms absent from docstrings, signatures, and logs. |
| **Large Commit Corruption** | Bulk commit ($> 25$ files) bypassed filtering, distorting co-change coupling. |
