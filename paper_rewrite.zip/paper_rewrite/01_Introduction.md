# Chapter I: Introduction

## 1.1 The Evolution and Mechanics of Distributed Version Control

Over the past three decades, the scope and complexity of software engineering have expanded drastically. What once began as self-contained utilities written by lone programmers has evolved into multi-million-line codebases maintained concurrently by hundreds of engineers across distributed environments. At this scale, modern software engineering relies on automated Continuous Integration and Continuous Deployment (CI/CD) pipelines, pull request code reviews, and distributed version control systems (DVCS) to preserve repository integrity and coordinate parallel work streams without destructive collisions.

In a distributed version control architecture—most notably embodied by Git—every developer workspace maintains an autonomous, fully realized mirror of the repository. Unlike older centralized systems (such as Subversion or CVS) that depend on constant network round-trips to an authoritative server for branching, inspecting logs, or computing diffs, Git executes virtually all configuration management operations locally:

* **Working Directory:** The mutable file system sandbox wherein developers edit source code.
* **Staging Area (Index):** A high-performance binary index caching modifications before serialization, enabling fine-grained, atomic commit composition.
* **Local Object Store:** An immutable, content-addressable database stored inside `.git/objects/`, representing historical snapshots as a cryptographically verified Directed Acyclic Graph (DAG).
* **Remote Upstream:** A peer synchronization nexus with which local repositories exchange packed commit objects via bulk push and fetch operations.

Underlying this topological workflow is Git's content-addressable storage model. Git does not store deltas between revisions as traditional delta-compression engines do; rather, it stores discrete snapshots using four fundamental object primitives:

1. **Blobs:** Unstructured byte streams representing the raw contents of a file revision, stripped of path names, permissions, or contextual metadata.
2. **Trees:** Hierarchical directory manifests mapping human-readable file names, mode flags, and subdirectories to their corresponding 160-bit SHA-1 or 256-bit SHA-256 object hashes.
3. **Commits:** Immutable snapshot descriptors binding a top-level root tree hash to one or more parent commit identifiers, alongside author identity, committer identity, Unix epoch timestamps, and free-form log messages.
4. **Tags & References:** Named pointers referencing specific commit nodes in the DAG (mutable branches pointing to branch heads, or immutable annotated tags containing cryptographic signatures).

Because every commit explicitly references the cryptographic hashes of its immediate parents, the commit graph forms an immutable Merkle DAG. Any retroactive mutation to an earlier file or commit header alters its cryptographic digest, inherently cascading down through all subsequent descendant commits and invalidating downstream tree hashes.

---

## 1.2 Version History as Institutional Knowledge

While version control systems were conceived primarily to prevent concurrent modification collisions and coordinate merge workflows, repository histories in practice serve a far deeper purpose: they represent the primary institutional memory of a software project. Code changes continually in response to shifting functional requirements, defect remediation, external dependency updates, and architectural redesigns. Consequently, reading the current source code reveals *how* a program currently executes, but almost never explains *why* particular architectural trade-offs, constraints, or non-obvious design choices were made.

Reconstructing this evolutionary rationale is the domain of *software archaeology*—the systematic investigation of historical change artifacts to recover institutional intent. A project's commit history provides three indispensable dimensions of forensic evidence:
* **Temporal Progression:** Granular timestamps document the chronology of architectural evolution, revealing when features were introduced, adjusted, or deprecated.
* **Author Attribution:** Modification logs reveal domain expertise by tracking which engineers or teams historically authored, refactored, and maintained specific subsystems.
* **Design Rationale:** Commit messages, coupled with referenced issue numbers and pull request discussions, document the motivations, trade-offs, and operational pressures that shaped the system's architecture.

In engineering environments characterized by high personnel mobility and rapid team turnover, human memory degrades rapidly. When senior architects and core maintainers depart, their tacit domain knowledge departs with them. The version control graph frequently remains the sole persistent, verifiable record of how a system arrived at its present architecture. Critical day-to-day software engineering tasks—including architectural code reviews, regression triage, refactoring risk assessment, and onboarding new contributors—depend directly on this historical record.

---

## 1.3 The Core Problem: The Historical Accessibility Gap

Despite the immense value embedded in commit logs, this institutional knowledge remains virtually inaccessible to both human engineers and modern AI tools. Three fundamental bottlenecks prevent effective exploitation of version control history:

### 1. The Cross-Modal Retrieval Gap
Engineers and architects express historical inquiries in natural, intent-oriented language (e.g., *"Why did we migrate our network pooling away from synchronous mutexes?"*). In contrast, version control systems store historical changes as raw unified diffs—a line-oriented, syntax-rigid format engineered specifically for patch application rather than semantic exploration. Standard keyword search engines (such as `git log --grep`) inevitably fail on conceptual inquiries because high-level architectural questions rarely share vocabulary tokens with the terse diff hunks or abbreviated commit messages that implement the change.

### 2. Loss of Function Identity Across Refactoring
Git's underlying object model is fundamentally file-centric. When an engineer renames a file, moves a helper function to a shared utility module, splits an oversized routine into multiple sub-functions, or updates a signature, Git's native tracking mechanisms (`git log -L` and `git blame`) routinely lose continuity. Consequently, the functions that undergo the most extensive architectural refactoring—which inherently carry the richest evolutionary rationale—possess the most fragmented, untraceable historical records.

### 3. Lack of Grounded Historical Context for AI Assistants
Autonomous coding agents and Large Language Models (LLMs) are now widely embedded in software development environments. However, these models operate exclusively on the contemporary working tree and possess zero grounded visibility into the project's historical commit timeline. When asked why a legacy architectural pattern was adopted or which modules historically suffer from co-change coupling, LLMs frequently fabricate plausible-sounding yet entirely fictitious rationales. Currently, developer workflows lack a lightweight, verifiable, and fully offline mechanism capable of feeding citation-backed repository history into language models without leaking private intellectual property or introducing nondeterministic latency.

---

## 1.4 Research Objectives and Contributions

To address these foundational limitations, this project designs and implements **gitctx**, an offline-first Git history intelligence platform written in Rust. Specifically, this work addresses four formal research questions:

* **RQ1 (Representation):** Can structured pseudo-document templates synthesized from AST deltas and identifier extraction outperform raw diffs and commit messages in retrieving historical design rationale?
* **RQ2 (Rank Fusion):** Does combining lexical BM25 indexing with dense semantic vector representations via Reciprocal Rank Fusion eliminate the opposing failure modes of sparse and dense retrievers on code history queries?
* **RQ3 (Lineage Integrity):** Can a four-tier locality-sensitive hashing cascade maintain unbroken function tracking across renames, signature migrations, and structural extractions without introducing false-positive decoy linkages?
* **RQ4 (Operational Feasibility):** Can a local-first history engine deliver sub-300ms query latency and strict deterministic reproducibility across heterogeneous environments while functioning entirely offline?

The remainder of this report is organized as follows: Chapter II surveys related literature across mining software repositories, code information retrieval, and agent grounding. Chapter III details the architectural design and system invariants of gitctx. Chapter IV presents the empirical evaluation methodology, while Chapter V and Chapter VI present the experimental results, validation benchmarks, and discussion.
